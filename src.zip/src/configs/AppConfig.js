const config = {
    AppName : 'AdverStud',
    Language: 'Ukrainian',
    DataBase: {
        server: '',
        port: '',
        user: '',
        password: '',
        name: ''
    },
};
export default config;
