const redux = require('redux');

//The model of data of Department
const initialState = {

};

export default function(state=initialState,action){
    switch(action.type){

    }
    return state;
};
